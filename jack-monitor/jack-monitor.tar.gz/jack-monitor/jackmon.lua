-- JACK monitor: un clic sinistro sul pannello apre/chiude i dettagli
local flag = os.getenv("HOME") .. "/.cache/jackmon-espanso"
function conky_jack_click(ev)
  if ev.type == "button_down" and ev.button == 1 then
    local f = io.open(flag, "r")
    if f then f:close(); os.remove(flag)
    else os.execute("mkdir -p '" .. os.getenv("HOME") .. "/.cache'"); f = io.open(flag, "w"); if f then f:write("1"); f:close() end end
    return true
  end
  return false
end
jack_click = conky_jack_click
