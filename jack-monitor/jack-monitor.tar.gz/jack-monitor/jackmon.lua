-- JACK monitor: clic = apre/chiude i dettagli · trascina = sposta il pannello (la posizione resta salvata)
local HOME = os.getenv("HOME")
local flag = HOME .. "/.cache/jackmon-espanso"
local drag = nil

local function sh(cmd) local p = io.popen(cmd); local o = p:read("*a"); p:close(); return o end
local function winpos()
  local o = sh("xdotool search --name '^jackmon$' getwindowgeometry --shell 2>/dev/null | head -5")
  local w = o:match("WINDOW=(%d+)"); local x = tonumber(o:match("X=(%-?%d+)")); local y = tonumber(o:match("Y=(%-?%d+)"))
  local wd = tonumber(o:match("WIDTH=(%d+)")); local ht = tonumber(o:match("HEIGHT=(%d+)"))
  return w, x, y, wd, ht
end
local function toggle()
  local f = io.open(flag, "r")
  if f then f:close(); os.remove(flag)
  else os.execute("mkdir -p '" .. HOME .. "/.cache'"); f = io.open(flag, "w"); if f then f:write("1"); f:close() end end
end

function conky_jack_click(ev)
  if ev.type == "button_down" and ev.button == 1 then
    local w, x, y = winpos()
    drag = { sx = ev.x_abs, sy = ev.y_abs, win = w, wx = x or 0, wy = y or 0, moved = false }
    return true
  elseif ev.type == "mouse_move" and drag then
    local dx, dy = ev.x_abs - drag.sx, ev.y_abs - drag.sy
    if math.abs(dx) + math.abs(dy) > 6 then drag.moved = true end
    if drag.moved and drag.win then
      os.execute(string.format("xdotool windowmove %s %d %d", drag.win, drag.wx + dx, drag.wy + dy))
    end
    return true
  elseif ev.type == "button_up" and ev.button == 1 and drag then
    if drag.moved then
      local _, x, y, wd, ht = winpos()
      if x then os.execute(string.format("jackmon posiziona %d %d %d %d &", x, y, wd, ht)) end
    else
      toggle()
    end
    drag = nil
    return true
  end
  return false
end
jack_click = conky_jack_click
