#!/usr/bin/env bash
# JACK monitor — pannello Conky sul desktop (ventola, temperature, CPU, RAM, disco, batteria, rete)
# Uso (SENZA sudo, la password te la chiede lui):  ./installa-monitor.sh
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
[ "$(id -u)" -ne 0 ] || { echo "Lancialo come utente normale, senza sudo:  ./installa-monitor.sh"; exit 1; }

echo "==> Pacchetti (conky + sensori)"
sudo apt-get install -y -qq conky-all lm-sensors >/dev/null
sudo install -m 755 "$HERE/jackmon" /usr/local/bin/jackmon

IFACE="$(ip route 2>/dev/null | awk '/^default/{print $5; exit}')"
[ -n "$IFACE" ] || IFACE="$(ls /sys/class/net | grep -m1 '^wl' || echo wlan0)"
echo "==> Scheda di rete: $IFACE"

mkdir -p "$HOME/.config/conky"
sed "s/IFACE/$IFACE/g" "$HERE/jack.conkyrc" > "$HOME/.config/conky/jack.conkyrc"
# meno di 4 thread? tolgo la riga dei core 3-4
if [ "$(nproc)" -lt 4 ]; then sed -i '/cpubar cpu3/d' "$HOME/.config/conky/jack.conkyrc"; fi

mkdir -p "$HOME/.config/autostart"
cat > "$HOME/.config/autostart/jack-monitor.desktop" <<DESK
[Desktop Entry]
Type=Application
Name=JACK monitor
Comment=Ventola, temperature e sistema sul desktop
Exec=sh -c "sleep 8 && conky -d -c $HOME/.config/conky/jack.conkyrc"
X-GNOME-Autostart-enabled=true
DESK

pkill -f "conky.*jack.conkyrc" 2>/dev/null || true
conky -d -c "$HOME/.config/conky/jack.conkyrc" >/dev/null 2>&1
echo
echo "Fatto: il pannello è in alto a destra e parte da solo a ogni accesso."
echo "Chiuderlo al volo:   pkill -f jack.conkyrc"
echo "Toglierlo del tutto: ./togli-monitor.sh"
