#!/usr/bin/env bash
pkill -f "conky.*jack.conkyrc" 2>/dev/null || true
rm -f "$HOME/.config/autostart/jack-monitor.desktop" "$HOME/.config/conky/jack.conkyrc" "$HOME/.config/conky/jackmon.lua" "$HOME/.cache/jackmon-espanso"
echo "JACK monitor tolto (conky resta installato, non dà fastidio)."
