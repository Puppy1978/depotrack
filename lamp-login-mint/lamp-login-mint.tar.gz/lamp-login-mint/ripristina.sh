#!/usr/bin/env bash
# Torna al login originale di Linux Mint (slick-greeter).
# Uso:  sudo lamp-login-ripristina     oppure     sudo ./ripristina.sh
# Opzione --tutto: toglie anche nody-greeter e il tema.
set -euo pipefail
[ "$(id -u)" -eq 0 ] || { echo "Lancialo con sudo:  sudo lamp-login-ripristina"; exit 1; }

rm -f /etc/lightdm/lightdm.conf.d/99-lamp-login.conf
MAIN="/etc/lightdm/lightdm.conf"
[ -f "$MAIN.prima-di-lamp-login" ] && mv -f "$MAIN.prima-di-lamp-login" "$MAIN"
echo "Login di Mint ripristinato (vale dal prossimo riavvio)."

if [ "${1:-}" = "--tutto" ]; then
  CFG="/etc/lightdm/web-greeter.yml"
  [ -f "$CFG.prima-di-lamp-login" ] && mv -f "$CFG.prima-di-lamp-login" "$CFG"
  rm -rf /usr/share/web-greeter/themes/lamp-login
  apt-get remove -y nody-greeter || true
  rm -f /usr/local/bin/lamp-login-ripristina
  echo "Tolti anche nody-greeter e il tema."
fi
echo "Riavvia con:  sudo reboot"
