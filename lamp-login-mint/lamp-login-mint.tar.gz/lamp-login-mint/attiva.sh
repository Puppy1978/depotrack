#!/usr/bin/env bash
# Attiva il Lamp Login come schermata di accesso di Linux Mint.
# Uso:  sudo ./attiva.sh      (effettivo dal prossimo riavvio)
set -euo pipefail
[ "$(id -u)" -eq 0 ] || { echo "Lancialo con sudo:  sudo ./attiva.sh"; exit 1; }
command -v nody-greeter >/dev/null || { echo "nody-greeter non installato: prima lancia  sudo ./installa.sh"; exit 1; }
[ -d /usr/share/web-greeter/themes/lamp-login ] || { echo "Tema non trovato: prima lancia  sudo ./installa.sh"; exit 1; }

MAIN="/etc/lightdm/lightdm.conf"
# se lightdm.conf impone già un greeter, lo commento (con copia di sicurezza) altrimenti vincerebbe lui
if [ -f "$MAIN" ] && grep -qE "^[[:space:]]*greeter-session[[:space:]]*=" "$MAIN"; then
  [ -f "$MAIN.prima-di-lamp-login" ] || cp "$MAIN" "$MAIN.prima-di-lamp-login"
  sed -i -E "s/^([[:space:]]*greeter-session[[:space:]]*=.*)/# \1   # disattivato da lamp-login/" "$MAIN"
fi

mkdir -p /etc/lightdm/lightdm.conf.d
cat > /etc/lightdm/lightdm.conf.d/99-lamp-login.conf <<'EOF'
# Lamp Login DepoTrack — per tornare al login di Mint:  sudo lamp-login-ripristina
[Seat:*]
greeter-session=nody-greeter
EOF

echo "Attivato. Al prossimo riavvio vedrai la lampada."
echo
echo "Se qualcosa va storto e non riesci a entrare:"
echo "  1. premi  Ctrl+Alt+F2"
echo "  2. entra con utente e password"
echo "  3. scrivi:  sudo lamp-login-ripristina"
echo "  4. poi:     sudo reboot"
echo
read -r -p "Riavvio adesso? [s/N] " r
[[ "${r,,}" == "s" ]] && reboot || echo "Ok, riavvia quando vuoi:  sudo reboot"
