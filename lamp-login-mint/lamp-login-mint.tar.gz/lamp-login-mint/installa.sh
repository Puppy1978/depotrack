#!/usr/bin/env bash
# Lamp Login DepoTrack — installazione su Linux Mint (LightDM + nody-greeter)
# Uso:  sudo ./installa.sh
# NON attiva ancora il nuovo login: prima lo provi, poi lanci  sudo ./attiva.sh
set -euo pipefail

THEME_NAME="lamp-login"
THEMES_DIR="/usr/share/web-greeter/themes"
HERE="$(cd "$(dirname "$0")" && pwd)"

[ "$(id -u)" -eq 0 ] || { echo "Lancialo con sudo:  sudo ./installa.sh"; exit 1; }
command -v lightdm >/dev/null || { echo "LightDM non trovato: questo script è per Linux Mint con LightDM."; exit 1; }

echo "==> 1/4  Pacchetti di base"
# un repository esterno rotto (es. Cursor senza chiave GPG) non deve bloccare l'installazione
apt-get update -qq || echo "    avviso: apt update ha dato errori su qualche repository esterno, continuo lo stesso"
apt-get install -y -qq curl ca-certificates x11-xserver-utils >/dev/null

echo "==> 2/4  nody-greeter"
if command -v nody-greeter >/dev/null; then
  echo "    già installato: $(nody-greeter --version 2>/dev/null | head -1)"
else
  DEB_URL="$(curl -fsSL https://api.github.com/repos/JezerM/nody-greeter/releases/latest \
            | grep -o '"browser_download_url": *"[^"]*\.deb"' | head -1 | cut -d'"' -f4 || true)"
  [ -n "$DEB_URL" ] || { echo "Non trovo il pacchetto .deb di nody-greeter su GitHub. Controlla la connessione e riprova."; exit 1; }
  echo "    scarico $DEB_URL"
  TMP="$(mktemp -d)"; chmod 755 "$TMP"; curl -fL --progress-bar -o "$TMP/nody-greeter.deb" "$DEB_URL"
  chmod 644 "$TMP/nody-greeter.deb"
  if ! apt-get install -y "$TMP/nody-greeter.deb"; then
    # Il .deb ufficiale chiede pacchetti di sviluppo (-dev) che su Mint non si installano.
    # Servono solo le librerie di runtime: le installo e ricostruisco il .deb senza i -dev.
    echo "    il pacchetto chiede librerie di sviluppo non disponibili su Mint: lo adatto"
    apt-get install -y gir1.2-lightdm-1 liblightdm-gobject-1-0 gobject-introspection
    # librerie che servono a Electron (su un desktop Mint di solito ci sono già)
    for p in libgtk-3-0 libnss3 libgbm1 libasound2t64 libasound2; do apt-get install -y -qq "$p" >/dev/null 2>&1 || true; done
    dpkg-deb -R "$TMP/nody-greeter.deb" "$TMP/pkg"
    python3 - "$TMP/pkg/DEBIAN/control" <<'PY'
import sys, re
p = sys.argv[1]; lines = open(p).read().split("\n")
for i, l in enumerate(lines):
    if l.startswith("Depends:"):
        deps = [d.strip() for d in l[len("Depends:"):].split(",") if d.strip()]
        keep = [d for d in deps if not re.match(r"^[^ (|]+-dev\b", d)]
        print("    tolti:", ", ".join(d for d in deps if d not in keep))
        if "gir1.2-lightdm-1" not in keep: keep.append("gir1.2-lightdm-1")
        lines[i] = "Depends: " + ", ".join(keep)
open(p, "w").write("\n".join(lines))
PY
    echo "    ricostruisco il pacchetto (un minuto)…"; dpkg-deb -Znone -b "$TMP/pkg" "$TMP/nody-greeter-mint.deb" >/dev/null
    chmod 644 "$TMP/nody-greeter-mint.deb"
    apt-get install -y "$TMP/nody-greeter-mint.deb"
  fi
  rm -rf "$TMP"
fi

# Electron su Mint 22 / Ubuntu 24.04: la sandbox di Chromium deve essere setuid root, altrimenti non parte
if [ -f /opt/nody-greeter/chrome-sandbox ]; then
  chown root:root /opt/nody-greeter/chrome-sandbox && chmod 4755 /opt/nody-greeter/chrome-sandbox
fi

echo "==> 3/4  Tema Lamp Login"
mkdir -p "$THEMES_DIR"
rm -rf "$THEMES_DIR/$THEME_NAME"
cp -r "$HERE/theme/$THEME_NAME" "$THEMES_DIR/$THEME_NAME"
chmod -R a+rX "$THEMES_DIR/$THEME_NAME"

echo "==> 4/4  Configurazione nody-greeter"
CFG="/etc/lightdm/web-greeter.yml"
if [ -f "$CFG" ]; then
  [ -f "$CFG.prima-di-lamp-login" ] || cp "$CFG" "$CFG.prima-di-lamp-login"
  sed -i -E "s/^([[:space:]]*)theme:.*/\1theme: $THEME_NAME/" "$CFG"
  # niente errori a schermo e niente richieste esterne
  sed -i -E "s/^([[:space:]]*)debug_mode:.*/\1debug_mode: False/; s/^([[:space:]]*)secure_mode:.*/\1secure_mode: True/" "$CFG"
  # niente "salvaschermo X" del greeter: altrimenti resta attivo anche dentro la sessione e spegne lo schermo ogni 5 minuti
  sed -i -E "s/^([[:space:]]*)screensaver_timeout:.*/\1screensaver_timeout: 0/" "$CFG"
  # tastiera italiana nel campo password
  grep -q "^[[:space:]]*- it$" "$CFG" || sed -i -E "0,/^layouts:/s//layouts:\n    - it/" "$CFG"
else
  echo "    ATTENZIONE: $CFG non trovato, nody-greeter potrebbe non essersi installato bene."; exit 1
fi

# comando di emergenza sempre a portata di mano
install -m 755 "$HERE/ripristina.sh" /usr/local/bin/lamp-login-ripristina

echo
echo "Installato. Il login di Mint NON è ancora cambiato."
echo
echo "PROVA (dalla tua sessione normale, senza sudo):"
echo "    nody-greeter --mode debug --theme $THEME_NAME"
echo "  si apre una finestra con il nuovo login: se vedi lampada e insegna, è tutto ok."
echo
echo "ATTIVA quando sei pronto:"
echo "    sudo ./attiva.sh"
