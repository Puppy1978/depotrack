#!/usr/bin/env bash
# Lamp Login DepoTrack — installazione su Linux Mint (LightDM + nody-greeter)
# Uso:  sudo ./installa.sh
# NON attiva ancora il nuovo login: prima lo provi, poi lanci  sudo ./attiva.sh
set -euo pipefail

THEME_NAME="lamp-login"
THEMES_DIR="/usr/share/web-greeter/themes"
HERE="$(cd "$(dirname "$0")" && pwd)"

[ "$(id -u)" -eq 0 ] || { echo "Lancialo con sudo:  sudo ./installa.sh"; exit 1; }
command -v lightdm >/dev/null || { echo "LightDM non trovato: questo script è per Linux Mint con LightDM."; exit 1; }

echo "==> 1/4  Pacchetti di base"
# un repository esterno rotto (es. Cursor senza chiave GPG) non deve bloccare l'installazione
apt-get update -qq || echo "    avviso: apt update ha dato errori su qualche repository esterno, continuo lo stesso"
apt-get install -y -qq curl ca-certificates x11-xserver-utils >/dev/null

echo "==> 2/4  nody-greeter"
if command -v nody-greeter >/dev/null; then
  echo "    già installato: $(nody-greeter --version 2>/dev/null | head -1)"
else
  DEB_URL="$(curl -fsSL https://api.github.com/repos/JezerM/nody-greeter/releases/latest \
            | grep -o '"browser_download_url": *"[^"]*\.deb"' | head -1 | cut -d'"' -f4 || true)"
  [ -n "$DEB_URL" ] || { echo "Non trovo il pacchetto .deb di nody-greeter su GitHub. Controlla la connessione e riprova."; exit 1; }
  echo "    scarico $DEB_URL"
  TMP="$(mktemp -d)"; curl -fL --progress-bar -o "$TMP/nody-greeter.deb" "$DEB_URL"
  apt-get install -y "$TMP/nody-greeter.deb"
  rm -rf "$TMP"
fi

echo "==> 3/4  Tema Lamp Login"
mkdir -p "$THEMES_DIR"
rm -rf "$THEMES_DIR/$THEME_NAME"
cp -r "$HERE/theme/$THEME_NAME" "$THEMES_DIR/$THEME_NAME"
chmod -R a+rX "$THEMES_DIR/$THEME_NAME"

echo "==> 4/4  Configurazione nody-greeter"
CFG="/etc/lightdm/web-greeter.yml"
if [ -f "$CFG" ]; then
  [ -f "$CFG.prima-di-lamp-login" ] || cp "$CFG" "$CFG.prima-di-lamp-login"
  sed -i -E "s/^([[:space:]]*)theme:.*/\1theme: $THEME_NAME/" "$CFG"
  # niente errori a schermo e niente richieste esterne
  sed -i -E "s/^([[:space:]]*)debug_mode:.*/\1debug_mode: False/; s/^([[:space:]]*)secure_mode:.*/\1secure_mode: True/" "$CFG"
  # tastiera italiana nel campo password
  grep -q "^[[:space:]]*- it$" "$CFG" || sed -i -E "0,/^layouts:/s//layouts:\n    - it/" "$CFG"
else
  echo "    ATTENZIONE: $CFG non trovato, nody-greeter potrebbe non essersi installato bene."; exit 1
fi

# comando di emergenza sempre a portata di mano
install -m 755 "$HERE/ripristina.sh" /usr/local/bin/lamp-login-ripristina

echo
echo "Installato. Il login di Mint NON è ancora cambiato."
echo
echo "PROVA (dalla tua sessione normale, senza sudo):"
echo "    nody-greeter --debug --theme $THEME_NAME"
echo "  si apre una finestra con il nuovo login: se vedi lampada e insegna, è tutto ok."
echo
echo "ATTIVA quando sei pronto:"
echo "    sudo ./attiva.sh"
